package pkg_DWR;

public class Movable {
	private int id;
	private int did;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public Movable(int id, int did) {
		super();
		this.id = id;
		this.did = did;
	}
	
	
	
}
