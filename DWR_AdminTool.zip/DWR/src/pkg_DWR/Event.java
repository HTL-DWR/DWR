package pkg_DWR;

import java.sql.Timestamp;

public class Event {
	private int id;
	private int dauer;
	private Timestamp beginn;
	public Event(int id, int dauer, Timestamp beginn) {
		super();
		this.id = id;
		this.dauer = dauer;
		this.beginn = beginn;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDauer() {
		return dauer;
	}
	public void setDauer(int dauer) {
		this.dauer = dauer;
	}
	public Timestamp getBeginn() {
		return beginn;
	}
	public void setBeginn(Timestamp beginn) {
		this.beginn = beginn;
	}
	
	
}
