package pkg_DWR;

public class GebTyp {
	private int id;
	private int base_buildtime;
	private String name;
	
	
	
	public GebTyp(int id, int base_buildtime, String name) {
		super();
		this.id = id;
		this.base_buildtime = base_buildtime;
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getBase_buildtime() {
		return base_buildtime;
	}
	public void setBase_buildtime(int base_buildtime) {
		this.base_buildtime = base_buildtime;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
}
