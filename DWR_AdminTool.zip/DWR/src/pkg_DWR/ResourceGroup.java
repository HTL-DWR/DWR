package pkg_DWR;

public class ResourceGroup {
	private int id; //Movable
	private int holz;
	private int stein;
	private int lehm;
	
	public ResourceGroup(int id, int holz, int stein, int lehm) {
		super();
		this.id = id;
		this.holz = holz;
		this.stein = stein;
		this.lehm = lehm;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getHolz() {
		return holz;
	}

	public void setHolz(int holz) {
		this.holz = holz;
	}

	public int getStein() {
		return stein;
	}

	public void setStein(int stein) {
		this.stein = stein;
	}

	public int getLehm() {
		return lehm;
	}

	public void setLehm(int lehm) {
		this.lehm = lehm;
	}
	
	
}
