package pkg_DWR;

public class Spieler {
	String uname;
	Clan clan;
	Spieler(String uname){
		this.uname=uname;
	}
	Spieler(String uname, Clan clan){
		this.uname=uname;
		this.clan=clan;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
	public Clan getClan() {
		return clan;
	}
	public void setClan(Clan clan) {
		this.clan = clan;
	}
	
}
