package pkg_DWR;

import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Admin extends Application{

	static Database db=null;
	
	public static void main(String[] args) {
		/*db=new Database("d5bhifs11", "d5bhifs11");
		try {
			db.createConnection();
			System.out.println(db.toString());
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		ResultSet rs = null;
		rs = db.getKommentare("Spamboard");
		try {
			 while(rs.next()){
				
				System.out.println(rs.getString("text"));
			
	    	 }
			 rs.close();
		 } catch (SQLException e) {
				System.out.println("Problem with rs " + e.getMessage() + e.getErrorCode());
			
		 }
	      //STEP 6: Clean-up environment*/
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		Parent rootframe = FXMLLoader.load(getClass().getResource("resource/AdminGUI.fxml"));
		//that was that
		Scene scene = new Scene(rootframe);
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
		
		
}


