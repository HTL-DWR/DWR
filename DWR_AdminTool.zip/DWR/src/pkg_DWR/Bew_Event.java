package pkg_DWR;

public class Bew_Event {
	private int id; // number references event(id),
	private int von_dorf;// number references dorf(id),
	private int nach_dorf; // number references dorf(id),
	private int cargo;// number references Movable(id),
	private BewEventArt art;// VARCHAR2(3) CHECK( art IN ('res','sup','atk') ),
	public Bew_Event(int id, int von_dorf, int nach_dorf, int cargo,
			BewEventArt art) {
		super();
		this.id = id;
		this.von_dorf = von_dorf;
		this.nach_dorf = nach_dorf;
		this.cargo = cargo;
		this.art = art;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getVon_dorf() {
		return von_dorf;
	}
	public void setVon_dorf(int von_dorf) {
		this.von_dorf = von_dorf;
	}
	public int getNach_dorf() {
		return nach_dorf;
	}
	public void setNach_dorf(int nach_dorf) {
		this.nach_dorf = nach_dorf;
	}
	public int getCargo() {
		return cargo;
	}
	public void setCargo(int cargo) {
		this.cargo = cargo;
	}
	public BewEventArt getArt() {
		return art;
	}
	public void setArt(BewEventArt art) {
		this.art = art;
	}
	
	
	
}
