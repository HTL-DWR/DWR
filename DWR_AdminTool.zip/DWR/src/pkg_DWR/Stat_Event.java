package pkg_DWR;

public class Stat_Event {
	private int id;// number references event(id),
	private int dorf;// number references dorf(id),
	private int geb_typ;// number references geb_typ(id),
	private int cargo;// number references Truppe(id),
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDorf() {
		return dorf;
	}
	public void setDorf(int dorf) {
		this.dorf = dorf;
	}
	public int getGeb_typ() {
		return geb_typ;
	}
	public void setGeb_typ(int geb_typ) {
		this.geb_typ = geb_typ;
	}
	public int getCargo() {
		return cargo;
	}
	public void setCargo(int cargo) {
		this.cargo = cargo;
	}
	public Stat_Event(int id, int dorf, int geb_typ, int cargo) {
		super();
		this.id = id;
		this.dorf = dorf;
		this.geb_typ = geb_typ;
		this.cargo = cargo;
	}
	
	
	
}
