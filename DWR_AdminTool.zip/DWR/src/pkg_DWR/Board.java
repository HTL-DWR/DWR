package pkg_DWR;

public class Board {
	int id;
	String name;
	Spieler op;
	public Board(int id, String name, Spieler op) {
		super();
		this.id = id;
		this.name = name;
		this.op = op;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Spieler getOp() {
		return op;
	}
	public void setOp(Spieler op) {
		this.op = op;
	}
	
	
}
