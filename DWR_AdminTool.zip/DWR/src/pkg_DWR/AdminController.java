package pkg_DWR;

import java.math.BigInteger;
import java.net.URL;
import java.security.MessageDigest;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableArray;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class AdminController implements Initializable{

	static Database db=null;
	
	@FXML
	private ListView listClan;
	
	@FXML
	private TableView tabBau;
	
	@FXML
	private TableView tabBoard;
	
	@FXML
	private TableView tabDorf;
	
	@FXML
	private TableView tabEvents;
	
	@FXML
	private TableView tabGebTyp;
	
	@FXML
	private TableView tabKommentare;
	
	@FXML
	private TableView tabMovables;
	
	@FXML
	private TableView tabResGroup;
	
	@FXML
	private TableView<Spieler> tabSpieler;
	
	@FXML
	private TextField txtBaseBuildTime;
	
	@FXML
	private TextField txtEUTimer;
	
	@FXML
	private TextField txtNameClan;
	
	@FXML
	private TextField txtNameDorf;
	
	@FXML
	private TextField txtNameGebTyp;
	
	@FXML
	private TextField txtOwnerDorf;
	
	@FXML
	private TextField txtPositionDorf;
	
	@FXML
	private TextField txtRUTimer;
	
	@FXML
	private TextField txtSpieler;

	@FXML
	private TextField txtSpielerPwd;

	private void SendQueryInsert(String string) {
		try {
			db.insert(string);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}
	
	private ResultSet SendQuerySelect(String string) {
		ResultSet rs = null;
		try {
			rs = db.getData(string);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return rs;	
	}
	
	
	
	@FXML
	private void onAction_btnAddClan(ActionEvent ae){
		try{
		String clanName = txtNameClan.getText();
		SendQueryInsert("BEGIN Create_Clan('"+clanName+"'); END;");
		}catch(Exception e){
			System.out.println("Error: " + e.getMessage());
		}
	}
	@FXML
	private void onAction_btnListStatEvents(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListGebTyp(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListBewEvents(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btn_AddGebTyp(ActionEvent ae){
		try{
		String name = txtNameGebTyp.getText();
		int baseBuildTime = Integer.parseInt(txtBaseBuildTime.getText());
		SendQueryInsert("BEGIN Create_Geb�ude_Typ('"+name+"','"+baseBuildTime+"'); END;");
		}catch(Exception e){
			System.out.println("Error: " + e.getMessage());
		}
	}
	@FXML
	private void onAction_btnAddDorf(ActionEvent ae){
		try{
			String dorfName = txtNameDorf.getText();
			String ownerDorf = txtOwnerDorf.getText();
			String posDorf = txtPositionDorf.getText();
			String[] splited = posDorf.split("/");
			int posDorfX = Integer.parseInt(splited[0]);
			int posDorfY = Integer.parseInt(splited[1]);
			SendQueryInsert("declare result number; BEGIN result := Create_Dorf('"+dorfName+"','"+ownerDorf+"','"+posDorfX+"','"+posDorfY+"'); END;");
		}catch(Exception e){
			System.out.println("Error: " + e.getMessage());
		}
	}
	@FXML
	private void onAction_btnAddSpieler(ActionEvent ae){
		try{
			String name = txtSpieler.getText();
			String pwd = txtSpielerPwd.getText();
			
			MessageDigest m = MessageDigest.getInstance("MD5");
			m.reset();
			m.update(pwd.getBytes());
			byte[] digest = m.digest();
			BigInteger bigInt = new BigInteger(1,digest);
			String hashtext = bigInt.toString(16);
			// Now we need to zero pad it if you actually want the full 32 chars.
			while(hashtext.length() < 32 ){
			  hashtext = "0"+hashtext;
			}
			SendQueryInsert("BEGIN Create_New_User('"+name+"','"+"Dorf von "+name+"','"+hashtext+"'); END;");
			
		}catch(Exception e){
			System.out.println("Error: " + e.getMessage());
		}
	}
	@FXML
	private void onAction_btnCreateEvent(ActionEvent ae){
		//Table Stuff. Dauert
	}
	@FXML
	private void onAction_btnListBau(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListBoards(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListClans(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListDorf(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListEvents(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListMovables(ActionEvent ae){
		
	}
	@FXML
	private void onAction_btnListResGroup(ActionEvent ae){
		
	}
	@FXML//----------------------now working ? O.o
	private void onAction_btnListSpieler(ActionEvent ae){
		ResultSet rs = null;
		ObservableList<Spieler> data = FXCollections.observableArrayList();
		rs = SendQuerySelect("select uname,clan from spieler");
		 try {
			while(rs.next()){
			     //Retrieve by column name
			     String name  = rs.getString("uname");
			     String clan = rs.getString("clan");
			     data.add(new Spieler(name,new Clan(0,clan)));
			 }
			tabSpieler.setItems(data);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		 
	}
	@FXML
	private void onAction_btnUpdateEUTimer(ActionEvent ae){
		db.EUTimer = Integer.parseInt(txtEUTimer.getText());
		db.updateConfig();
	}
	@FXML
	private void onAction_btnUpdateRUTimer(ActionEvent ae){
		db.RUTimer = Integer.parseInt(txtRUTimer.getText());
		db.updateConfig();
	}
	
	
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
	// nothing to do
		db=new Database("d5bhifs11", "d5bhifs11");
		txtEUTimer.setText(""+db.EUTimer);
		txtRUTimer.setText(""+db.RUTimer);
	}
	
}
