package pkg_DWR;

public enum BewEventArt {
	RES,
	SUP,
	ATK;
}
