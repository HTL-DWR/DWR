package pkg_DWR;

public class Bau {
	private int did;
	private int tid; // number references geb_typ(id),
	private int lvl;
	
	public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getLvl() {
		return lvl;
	}
	public void setLvl(int lvl) {
		this.lvl = lvl;
	}
	public Bau(int did, int tid, int lvl) {
		super();
		this.did = did;
		this.tid = tid;
		this.lvl = lvl;
	}
	
	
	
}
