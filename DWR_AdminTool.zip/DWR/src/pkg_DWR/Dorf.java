package pkg_DWR;

public class Dorf {
	int id;
	String name;
	Spieler owner;
	int positionX; //will be changed
	int positionY;
	public Dorf(int id, String name, Spieler owner, int positionX, int positionY) {
		super();
		this.id = id;
		this.name = name;
		this.owner = owner;
		this.positionX = positionX;
		this.positionY = positionY;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Spieler getOwner() {
		return owner;
	}
	public void setOwner(Spieler owner) {
		this.owner = owner;
	}
	public int getPositionX() {
		return positionX;
	}
	public int getPositionY() {
		return positionY;
	}
	
	public String getPositions(){
		return positionX+"/"+positionY;
	}
	public void setPositionX(int position) {
		this.positionX = position;
	}
	public void setPositionY(int position) {
		this.positionY = position;
	}
	
	
}
