package pkg_DWR;

public class Truppe {
	private int id;// number references Movable(id),
	private int schwert;// number,
	private int reiter;// number,
	private int bogen;// number,
	private int lanze;// number,
	private String owner;// varchar2(20) references Spieler(uname),
	
	public Truppe(int id, int schwert, int reiter, int bogen, int lanze,
			String owner) {
		super();
		this.id = id;
		this.schwert = schwert;
		this.reiter = reiter;
		this.bogen = bogen;
		this.lanze = lanze;
		this.owner = owner;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSchwert() {
		return schwert;
	}
	public void setSchwert(int schwert) {
		this.schwert = schwert;
	}
	public int getReiter() {
		return reiter;
	}
	public void setReiter(int reiter) {
		this.reiter = reiter;
	}
	public int getBogen() {
		return bogen;
	}
	public void setBogen(int bogen) {
		this.bogen = bogen;
	}
	public int getLanze() {
		return lanze;
	}
	public void setLanze(int lanze) {
		this.lanze = lanze;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	
	
}
