package pkg_DWR;

public class Kommentar {
	int id;
	Board board;
	Spieler op;
	String text;
	public Kommentar(int id, Board board, Spieler op, String text) {
		super();
		this.id = id;
		this.board = board;
		this.op = op;
		this.text = text;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Board getBoard() {
		return board;
	}
	public void setBoard(Board board) {
		this.board = board;
	}
	public Spieler getOp() {
		return op;
	}
	public void setOp(Spieler op) {
		this.op = op;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
	
	
}
