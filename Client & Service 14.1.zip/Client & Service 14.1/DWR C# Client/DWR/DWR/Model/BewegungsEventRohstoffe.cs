﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWR.Model
{
    public class BewegungsEventRohstoffe
    {
        public Dorf ziel { get; set; }
        public Rohstoffe rohstoffe { get; set; }

        public BewegungsEventRohstoffe() {}
    }
}
