﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DWR.Model
{
    public class Event
    {
        public DateTime beginn { get; set; }
        public TimeSpan dauer;

        public Event() { }
    }
}
