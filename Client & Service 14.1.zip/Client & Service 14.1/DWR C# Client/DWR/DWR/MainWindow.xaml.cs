﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DWR.Model;
using System.Data;

namespace DWR
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Spieler spieler;
        private GlobalMap gm;
        private Notification nw;
        private Benachrichtigung bw;
        private String ConnectionString = "Provider=OraOLEDB.Oracle; Data Source=212.152.179.117:1521/ora11g; User Id=d5bhifs11;Password=d5bhifs11;OLEDB.NET=True;";
        private Dorf dorf;
        //private String ConnectionString = "Provider=OraOLEDB.Oracle; Data Source=192.168.128.151:1521/ora11g; User Id=d5bhifs11;Password=d5bhifs11;OLEDB.NET=True;";

        public MainWindow(String _username)
        {
            InitializeComponent();

            try
            {
                Spieler spieler = WebServiceCom.newInstance().getSpielerDetial(_username);

                //MessageBox.Show(spieler.doerfer[0].ToString());

                dorf = WebServiceCom.newInstance().getDorfDetial(spieler.doerfer[0]);
                
                GridDoerfer.ItemsSource = spieler.doerfer;

                fillWithDorfData(dorf);
                InitializeComponent();
                /*spieler.doerfer = getDoerferNames();
                GridDoerfer.SelectedIndex = 0;

                fillWithDorfData((Dorf)GridDoerfer.SelectedItem);*/
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void fillWithDorfData(Dorf dorf) {
            lblDorfName.Content = dorf.name;

            lblAmountHolz.Content = dorf.rohstoffe.holz;
            lblAmountStein.Content = dorf.rohstoffe.stein;
            lblAmountLehm.Content = dorf.rohstoffe.lehm;

            lblAmountFighters.Content = dorf.truppen.schwert;
            lblAmountRiders.Content = dorf.truppen.reiter;
            lblAmountLancer.Content = dorf.truppen.lanze;
            lblAmountArcher.Content = dorf.truppen.bogen;

            GridGebäude.ItemsSource = dorf.gebaude;

            pnlMap.Background = Brushes.DarkGreen;
            Canvas Gebäude = addPictureToBuilding();
            pnlMap.Content = Gebäude;
            pnlMap.VerticalScrollBarVisibility = ScrollBarVisibility.Hidden;

        }

        private Canvas addPictureToBuilding()
        {
            Canvas GebäudeInDorf = new Canvas();

            int top = 40;
            int left = 20;
            int counter = 0;

            foreach(Gebaeude g in dorf.gebaude)
            {   
                Rectangle Rectangle = new Rectangle();
                Rectangle.Width = 60;
                Rectangle.Height = 30;
                ImageBrush ib = new ImageBrush();
                ib.ImageSource = new BitmapImage(new Uri("pack://application:,,,/Resources/"+ g.name.ToLower()+".png"));
                Rectangle.Fill = ib;
                Canvas.SetLeft(Rectangle, top); //Betrag einer Zahl
                Canvas.SetTop(Rectangle, left);
                GebäudeInDorf.Children.Add(Rectangle);

                if (counter < 3 )
                {
                    top += 20;
                }
                else
                {
                    counter = 0;
                    top -= 60;
                    left += 20;
                }
            }

            return GebäudeInDorf;
        }

        private void MenuItemMap_Click(object sender, RoutedEventArgs e)
        {
            gm = new GlobalMap();
            gm.Show();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nw = new Notification();
            nw.Show();
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            bw = new Benachrichtigung();
            bw.Show();
        }
    }
}
