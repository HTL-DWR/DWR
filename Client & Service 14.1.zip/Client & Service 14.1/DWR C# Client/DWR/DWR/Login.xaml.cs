﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DWR.Model;
using System.Data;
using System.Data.OleDb;
using System.Media;

using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

using System.Xml;

using System.Xml.Serialization;
using System.IO;

namespace DWR
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
       
        private String ConnectionString = "Provider=OraOLEDB.Oracle; Data Source=212.152.179.117:1521/ora11g; User Id=d5bhifs11;Password=d5bhifs11;OLEDB.NET=True;";
        //private String ConnectionString = "Provider=OraOLEDB.Oracle; Data Source=192.168.128.151:1521/ora11g; User Id=d5bhifs11;Password=d5bhifs11;OLEDB.NET=True;";

        private static MD5hash hasher = new MD5hash();


        public Login()
        {
            InitializeComponent();


            //SoundPlayer player = new SoundPlayer("pack://application:,,,/Resources/song.wav");
            //player.Play();
        }

        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
               MessageBox.Show(WebServiceCom.newInstance().register(txtUser.Text, txtPassowrd.Password));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {               
                LoginStatus ls = WebServiceCom.newInstance().login(txtUser.Text, txtPassowrd.Password);

                if (ls.status.Contains("Username Falsch") || ls.status.Contains("Passwort Falsch"))
                {
                    throw new Exception("Login fehlgeschlagen: " + ls.status);
                }

                MainWindow mw = new MainWindow(txtUser.Text);
                mw.Show();
                this.Close();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }  
        }
    }
}
