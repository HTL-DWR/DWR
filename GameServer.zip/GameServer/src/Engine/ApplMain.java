package Engine;

public class ApplMain {
	public static void main(String[] args)
	{
		Engine e = new Engine();
		e.start();
		
	}
}
