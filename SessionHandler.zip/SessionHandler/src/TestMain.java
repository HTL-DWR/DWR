
public class TestMain {

	public static void main(String[] args) {
		// TODO !!!!!!!! uname und passwd nicht mehr in der session speichern. bessere lösung finden (zB in user in db session_id speichern, oder einfach so lassen. ist eigentlich nicht so schlecht. aber man bräuchte nur den uname, das passwort nicht.
		Session.session_lifetime = 10 * 1000;
		SessionDB db = new SessionDB();
		int[] sessionReturn = new int[3];
		sessionReturn[0] = db.newSession("stefan", "123");
		System.out.println("stefan has session-code "+sessionReturn[0]);
		sessionReturn[1] = db.newSession("peter", "batman");
		System.out.println("peter has session-code "+sessionReturn[1]);
		sessionReturn[2] = db.newSession("tino", "asdf");
		System.out.println("tino has session-code "+sessionReturn[2]);
		System.out.println(db.toString());
		
		//here comes the normal handling of querys through the webservice. the session_id has to be returned to the user
		//the session_id and the username has to be sent to us with every user-specific query (clan, dorf, board, etc).
		//not nesecarily with give map in this area.
		 if( db.checkSession(sessionReturn[1]) )
		 {
			 String name = db.getSession_User(sessionReturn[1]).getUname();
			 System.out.println("user has beed successfully identified as "+name);
		 }
		
		try {
			Thread.sleep(1000 * 30);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
