import java.util.Date;
import java.util.Observer;


public class Session {
	private String uname;
	private SessionClock  clock =  null;
	public static long session_lifetime;
	private static long session_id_pot = 0;
	private long session_id;
	
	public String getUname() {
		return uname;
	}
	public long getSession_id() {
		return session_id;
	}

	public Session(String uname, String passwd_hc) throws Exception {
		super();
		String returnedString="true";
		//select DECODE('true',... select von zeiringer
		if(!returnedString.equals("true"))
		{
			throw new Exception("no match for this uname-passwd combination");
		}
		
		this.uname = uname;
		clock = new SessionClock(this,session_lifetime);
		session_id = session_id_pot++;
	}

	@Override
	public String toString() {
		return "Session '" + session_id + "' of " + uname;
	}

	public void notifyOnTimeout(Observer ob)
	{
		System.out.println("will notify on thimeout");
		clock.newObserver(ob);
	}	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (session_id ^ (session_id >>> 32));
		result = prime * result + ((uname == null) ? 0 : uname.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Session other = (Session) obj;
		if (session_id != other.session_id)
			return false;
		if (uname == null) {
			if (other.uname != null)
				return false;
		} else if (!uname.equals(other.uname))
			return false;
		return true;
	}
}
